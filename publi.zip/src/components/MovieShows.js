import React, { useEffect, useState } from 'react'
import MovieShowsItems from './MovieShowsItems'

const MovieShows = () => {
    const [articles, setArticles] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(false);

    const [showForm, setShowForm] = useState(false);
    const [movieDetails, setMovieDetails] = useState(null);
    const [formData, setFormData] = useState({
        name: "",
        mobile: "",
        email: "",
        noOfTickets: ""
    });

    const setLocalStorage = async () => {
        console.log(formData);
        localStorage.setItem("MovieData", JSON.stringify(formData));
    }



    useEffect(() => {

        const fetchData = async () => {
            let url = "https://api.tvmaze.com/search/shows?q=all";
            fetch(url).then((res) => res.json())
                .then((res) => {
                    setArticles([...res])
                    setLoading(false);
                    setError(false);
                })
                .catch((err) => {
                    console.log(err);
                    setLoading(false);
                    setError(true);
                })
        }
        fetchData();
    }, [])

    return (
        <div className='container my-4'>
            <h2 className='text-center m-4'>All Shows</h2>
            {loading ?
                <div class="spinner-border" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div> :
                error ?
                    <div>
                        <h2>
                            Sorry for the inconvenience. Network Error.
                        </h2>
                    </div>
                    :
                    movieDetails === null ?
                        <div className="row">
                            {articles.map((element) => {
                                return <div className="col-md-4" key={element.id}>
                                    <MovieShowsItems setMovieDetails={setMovieDetails} title={element.show.name} description={element.show.summary} imageUrl={element.show.image?.medium ?? "https://static.tvmaze.com/uploads/images/medium_portrait/413/1034988.jpg"} />
                                </div>
                            })}
                        </div> :
                        <div className='container my-3'>
                            <div className="row justify-content-end">
                                <div className="col-auto ">
                                    <button onClick={() => {
                                        setMovieDetails(null);
                                        setShowForm(false);

                                    }} className="btn btn-sm btn-primary">Go Back</button>
                                </div>
                            </div>
                            <div className="row" >
                                <div className="col-6">
                                    <img src={movieDetails.imageUrl} className="card-img-top" alt="..." />
                                    <div className="card-body">
                                        <h5 className="card-title">{movieDetails.title}</h5>
                                        <p className="card-text" dangerouslySetInnerHTML={{ __html: movieDetails.description }} ></p>
                                    </div>
                                </div>
                                <div className="col-6">

                                    {showForm ?
                                        <>
                                            <div class="mb-3">
                                                <label for="Moviename" class="form-label">MOVIE Name</label>
                                                <input type="email" class="form-control" id="Moviename" value={movieDetails.title} />
                                            </div>
                                            <div class="mb-3">
                                                <label for="Name" class="form-label">Name</label>
                                                <input type="text" onInput={(e) => { setFormData({ ...formData, name: e.target?.value }) }} class="form-control" id="Name" placeholder="Enter Your Name" />
                                            </div>
                                            <div class="mb-3">
                                                <label for="mobile" class="form-label">Mobile No</label>
                                                <input type="Number" onInput={(e) => { setFormData({ ...formData, mobile: e.target?.value }) }} class="form-control" id="mobile" placeholder="Enter Your Mobile No" />
                                            </div>
                                            <div class="mb-3">
                                                <label for="email" class="form-label">Email address</label>
                                                <input type="email" onInput={(e) => { setFormData({ ...formData, email: e.target?.value }) }} class="form-control" id="email" placeholder="name@example.com" />
                                            </div>
                                            <div class="mb-3">
                                                <label for="Nos" class="form-label">No. Tickets</label>
                                                <input type="Number" onInput={(e) => { setFormData({ ...formData, noOfTickets: e.target?.value }) }} class="form-control" id="Nos" placeholder="Enter No of Tickets" />
                                            </div>
                                            <div class="mb-3">
                                                <button onClick={() => { setLocalStorage() }} type="submit" className=" form-control btn btn-sm btn-primary" id="submit" >Submit</button>
                                            </div>
                                        </>
                                        :
                                        <button className="btn btn-sm btn-success" onClick={() => {
                                            setShowForm(true);
                                        }}>Book Movie Tickets</button>
                                    }
                                </div>
                            </div>
                        </div>
            }
        </div>
    )
}

export default MovieShows
