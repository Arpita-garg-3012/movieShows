import React from 'react'

const MovieShowsItems = (props) => {
    let { title, description, imageUrl, setMovieDetails } = props;

    return (
        <div className='container my-3'>
            <div className="card" style={{ width: "18rem" }}>
                <img src={imageUrl} className="card-img-top" alt="..." />
                <div className="card-body">
                    <h5 className="card-title">{title}</h5>
                    <p className="card-text" dangerouslySetInnerHTML={{__html: description.slice(0, 150)}} ></p>
                    <button onClick={() => { setMovieDetails({ title, description, imageUrl }) }} className="btn btn-sm btn-primary">Read more</button>
                </div>
            </div>
        </div>
    )
}
export default MovieShowsItems;
