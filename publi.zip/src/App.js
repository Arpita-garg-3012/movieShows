import './App.css';
import React from 'react'
import NavBar from './components/NavBar';
import MovieShows from './components/MovieShows';



const App = () => {
  return (
    <div>
      <NavBar />
      <MovieShows />
    </div>
  )
}

export default App;
